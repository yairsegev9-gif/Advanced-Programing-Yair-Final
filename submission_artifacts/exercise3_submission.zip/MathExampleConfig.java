package test;

public class MathExampleConfig implements Config {
    private BinOpAgent plus;
    private BinOpAgent minus;
    private BinOpAgent mul;

    @Override
    public void create() {
        plus = new BinOpAgent("plus", "A", "B", "R1", (x, y) -> x + y);
        minus = new BinOpAgent("minus", "A", "B", "R2", (x, y) -> x - y);
        mul = new BinOpAgent("mul", "R1", "R2", "R3", (x, y) -> x * y);
    }

    @Override
    public String getName() {
        return "Math Example";
    }

    @Override
    public int getVersion() {
        return 1;
    }

    @Override
    public void close() {
        if (plus != null) {
            plus.close();
        }
        if (minus != null) {
            minus.close();
        }
        if (mul != null) {
            mul.close();
        }
    }
}